import React, { useState, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { 
  Microscope, 
  GraduationCap, 
  Award, 
  FileText, 
  Mail, 
  Phone, 
  MapPin, 
  Download,
  ExternalLink,
  Calendar,
  Users,
  BookOpen,
  Beaker,
  Heart,
  Shield,
  ChevronDown,
  Menu,
  X,
  Globe,
  Building,
  FlaskConical,
  Stethoscope,
  Search,
  BarChart3
} from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import './App.css';

// Import images
import labEquipmentImg from './assets/lab-equipment.jpg';
import microbiologyLabImg from './assets/microbiology-lab.jpg';
import veterinaryCareerImg from './assets/veterinary-career.jpg';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '50%']);

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'education', 'research', 'experience', 'skills', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const skills = [
    { name: 'Microbiology Techniques', level: 95 },
    { name: 'PCR & RT-PCR', level: 90 },
    { name: 'Laboratory Management', level: 88 },
    { name: 'Research Methodology', level: 92 },
    { name: 'Data Analysis (R, SPSS)', level: 85 },
    { name: 'Scientific Writing', level: 90 },
    { name: 'Veterinary Diagnostics', level: 87 },
    { name: 'Antibiotic Susceptibility Testing', level: 93 },
    { name: 'MALDI-TOF', level: 80 },
    { name: 'Cell Culture', level: 82 }
  ];

  const experiences = [
    {
      title: 'Intern Trainee',
      company: 'Central Disease Investigation Laboratory, Dhaka',
      period: 'June 2025 - Present',
      description: 'Conducting clinical sample collection and processing, performing molecular diagnostics using PCR techniques for pathogen detection and confirmation.',
      achievements: [
        'Collected and processed clinical samples',
        'Conducted molecular diagnostics using PCR techniques',
        'Performed microbiological techniques to identify pathogens',
        'Maintained accurate laboratory records',
        'Ensured proper disposal of biohazardous materials'
      ]
    },
    {
      title: 'Research Officer',
      company: 'Infectious Disease Division, icddr,b',
      period: 'June 2024 - September 2024',
      description: 'Led research on Strategies to Prevent (STOP) Spillover (Avian Influenza) project, supervising ethical sample collection and developing research protocols.',
      achievements: [
        'Supervised ethical sample collection procedures',
        'Developed and implemented research protocols',
        'Conducted comprehensive data analysis',
        'Manuscript and report writing',
        'Project documentation and management'
      ]
    },
    {
      title: 'Brand Executive',
      company: 'SBMD-Vet, Navana Pharmaceuticals PLC',
      period: 'February 2023 - May 2024',
      description: 'Managed product portfolio and conducted scientific seminars while developing promotional tools and training field representatives.',
      achievements: [
        'Conducted data analysis for product development',
        'Developed scientific promotional tools',
        'Organized and conducted scientific seminars',
        'Maintained comprehensive product portfolio',
        'Trained field representatives and farmers',
        'Contributed to new product development initiatives'
      ]
    },
    {
      title: 'Research Assistant',
      company: 'Department of Microbiology and Parasitology, SAU',
      period: 'January 2020 - December 2020',
      description: 'Conducted comprehensive research on bacterial identification and antibiotic sensitivity profiling.',
      achievements: [
        'Sample collection and preparation',
        'Bacterial culture and identification',
        'Data collection and analysis',
        'Manuscript writing and publication'
      ]
    }
  ];

  const education = [
    {
      degree: 'Master of Science (MS) in Microbiology',
      institution: 'Sher-e-Bangla Agricultural University (SAU), Dhaka, Bangladesh',
      year: '2019 - 2021',
      gpa: '3.66/4.00 (72%) - WES: 3.84',
      thesis: 'Occurrence and Antibiotic Sensitivity Profiling of Staphylococcus aureus Bacteria Isolated from Raw Chevon',
      honors: ['National Science & Technology Fellowship (2020)']
    },
    {
      degree: 'Bachelor of Science in Veterinary Science & Animal Husbandry',
      institution: 'Sher-e-Bangla Agricultural University (SAU), Dhaka, Bangladesh',
      year: '2014 - 2018',
      gpa: '3.44/4.00 (68%) - WES: 3.52',
      project: 'Cattle Genetics Resources and their Conservation in Bangladesh',
      honors: ['Class Representative (2014-2019)', 'Joint Secretary, Chapai Nawabgonj Veterinary Association']
    }
  ];

  const research = [
    {
      title: 'Occurrence and antibiotic sensitivity profiling of Staphylococcus aureus isolated from raw chevon',
      status: 'Published',
      journal: 'Journal of Sher-e-Bangla Agricultural University',
      year: '2023',
      volume: '14(1&2): 17-23',
      authors: 'Hasnain, N., Khatu, A., Islam, M., and Mannan, M. A.',
      description: 'Comprehensive study investigating the prevalence and antibiotic resistance patterns of Staphylococcus aureus in raw goat meat.',
      impact: 'Contributed to food safety guidelines and antimicrobial stewardship'
    }
  ];

  const fundedProjects = [
    {
      title: 'Addressing Feed Shortages Through Exploration of Unconventional Feed Resources for Accelerated Livestock Development in Bangladesh',
      agency: 'Food and Agriculture Organization of the United Nations (FAO)',
      role: 'Research Assistant',
      description: 'Exploring alternative feed resources to address livestock feed shortages in Bangladesh.'
    },
    {
      title: 'Assessment of Community Supporting Team (CST) Intervention on COVID-19',
      agency: 'World Health Organization (WHO)',
      role: 'Field Support',
      description: 'Evaluating community-based interventions for COVID-19 response and management.'
    },
    {
      title: 'Determining Density of Tobacco Retail Outlets and Patterns of Tobacco Use Near Schools in Dhaka',
      agency: 'Bangladesh Center for Communication Programs (BCCP)',
      role: 'Field Research Contributor',
      description: 'Mapping tobacco retail density and usage patterns in school proximity areas.'
    }
  ];

  const researchInterests = [
    'Antimicrobial Resistance',
    'Antibiotic Stewardship',
    'One Health',
    'Food Microbiology',
    'Infectious Disease Epidemiology',
    'Infectious and Zoonotic Disease Surveillance',
    'Wildlife Ecology'
  ];

  const trainings = [
    {
      title: 'Clinical Training on Farm Animals',
      institution: 'Upazila Veterinary Hospital, Shibgonj, Chapai Nawabgonj',
      duration: 'One month',
      role: 'Intern Doctor'
    },
    {
      title: 'Clinical Training on Equine and Canine Medicine',
      institution: 'Remount Veterinary and Farm Corps (RVFC), Military Farm, Savar',
      duration: 'Fifteen days'
    },
    {
      title: 'Clinical and Management Training on Zoo and Wildlife Animals',
      institution: 'Bangladesh National Zoo, Mirpur, Dhaka',
      duration: 'Fifteen days'
    },
    {
      title: 'Training on Diagnostic Procedures',
      institution: 'West Bengal University of Animal & Fishery Sciences, Kolkata, India',
      duration: 'Twenty days'
    },
    {
      title: 'Clinical Training on Small Animal Medicine',
      institution: 'Central Veterinary Hospital, Dhaka',
      duration: 'Fifteen days'
    },
    {
      title: 'Training on Diagnostic Laboratory Procedures',
      institution: 'Central Disease Investigation Laboratory (CDIL), Dhaka',
      duration: 'One week'
    },
    {
      title: 'Training on Postmortem and Disease Diagnosis of Poultry',
      institution: 'Kazi Farms Bangladesh, Gazipur',
      duration: 'Five days'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-xl font-bold text-primary"
            >
              MD Nehal Hasnain
            </motion.div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8">
              {['home', 'about', 'education', 'research', 'experience', 'skills', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`capitalize transition-colors hover:text-primary ${
                    activeSection === section ? 'text-primary font-medium' : 'text-muted-foreground'
                  }`}
                >
                  {section}
                </button>
              ))}
            </div>

            {/* Mobile Navigation Toggle */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Navigation Menu */}
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="md:hidden mt-4 py-4 border-t"
            >
              {['home', 'about', 'education', 'research', 'experience', 'skills', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="block w-full text-left py-2 capitalize hover:text-primary transition-colors"
                >
                  {section}
                </button>
              ))}
            </motion.div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <motion.div 
          style={{ y }}
          className="absolute inset-0 hero-gradient opacity-10"
        />
        <div className="container mx-auto px-4 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Microscope size={48} className="text-white" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              MD Nehal Hasnain
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              Veterinary Microbiologist & Research Scientist
            </p>
            <p className="text-lg text-muted-foreground mb-12 max-w-2xl mx-auto">
              Advancing animal health through innovative microbiology research, antimicrobial resistance studies, and One Health approaches to infectious disease prevention.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => scrollToSection('about')} className="group">
                Learn More About Me
                <ChevronDown className="ml-2 group-hover:translate-y-1 transition-transform" size={20} />
              </Button>
              <Button size="lg" variant="outline" className="group">
                Download CV
                <Download className="ml-2 group-hover:translate-y-1 transition-transform" size={20} />
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">About Me</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A dedicated veterinary microbiologist with expertise in antimicrobial resistance research, infectious disease surveillance, and One Health approaches to public health challenges.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src={veterinaryCareerImg} 
                alt="Veterinary Career" 
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <FlaskConical className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Research Excellence</h3>
                  <p className="text-muted-foreground">Specialized in antimicrobial resistance and infectious disease research with published findings in peer-reviewed journals.</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Stethoscope className="text-accent" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">Clinical Expertise</h3>
                  <p className="text-muted-foreground">Extensive clinical training across multiple veterinary disciplines including farm animals, small animals, and wildlife medicine.</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Globe className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold">One Health Advocate</h3>
                  <p className="text-muted-foreground">Committed to the One Health approach, understanding the interconnection between animal, human, and environmental health.</p>
                </div>
              </div>

              <p className="text-muted-foreground leading-relaxed">
                Currently serving as an Intern Trainee at the Central Disease Investigation Laboratory in Dhaka, I bring a unique combination of veterinary clinical knowledge and advanced microbiology research skills. My work focuses on antimicrobial resistance, food safety, and infectious disease surveillance, contributing to both animal welfare and public health protection.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Education</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Strong academic foundation in veterinary science complemented by specialized training in microbiology and research methodology.
            </p>
          </motion.div>

          <div className="space-y-8">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="card-hover">
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div>
                        <CardTitle className="text-xl mb-2">{edu.degree}</CardTitle>
                        <CardDescription className="text-lg">{edu.institution}</CardDescription>
                      </div>
                      <div className="text-right mt-4 md:mt-0">
                        <Badge variant="secondary" className="text-sm">
                          {edu.year}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">GPA: {edu.gpa}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {edu.thesis && (
                      <p className="text-muted-foreground mb-3">
                        <strong>Thesis:</strong> {edu.thesis}
                      </p>
                    )}
                    {edu.project && (
                      <p className="text-muted-foreground mb-3">
                        <strong>Project:</strong> {edu.project}
                      </p>
                    )}
                    <div className="flex flex-wrap gap-2">
                      {edu.honors.map((honor, honorIndex) => (
                        <Badge key={honorIndex} variant="outline">
                          <Award size={14} className="mr-1" />
                          {honor}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Research Section */}
      <section id="research" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Research & Publications</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Contributing to scientific knowledge through research in antimicrobial resistance, food safety, and infectious disease surveillance.
            </p>
          </motion.div>

          {/* Published Research */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold mb-6">Published Research</h3>
            {research.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="card-hover research-card">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg leading-tight">{project.title}</CardTitle>
                      <Badge variant="default" className="ml-2 shrink-0">
                        {project.status}
                      </Badge>
                    </div>
                    <CardDescription>
                      {project.authors} ({project.year}). <em>{project.journal}</em>, {project.volume}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{project.description}</p>
                    <div className="flex items-center text-sm text-accent">
                      <ExternalLink size={16} className="mr-2" />
                      {project.impact}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Funded Projects */}
          <div className="mb-12">
            <h3 className="text-2xl font-bold mb-6">Funded Research Projects</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {fundedProjects.map((project, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <Card className="card-hover h-full">
                    <CardHeader>
                      <CardTitle className="text-lg leading-tight">{project.title}</CardTitle>
                      <CardDescription>
                        <strong>Funding Agency:</strong> {project.agency}
                      </CardDescription>
                      <Badge variant="outline" className="w-fit">
                        {project.role}
                      </Badge>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground text-sm">{project.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Research Interests */}
          <div>
            <h3 className="text-2xl font-bold mb-6">Research Interests</h3>
            <div className="flex flex-wrap gap-3">
              {researchInterests.map((interest, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Badge variant="secondary" className="text-sm py-2 px-4">
                    <Search size={14} className="mr-2" />
                    {interest}
                  </Badge>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Professional Experience</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive experience spanning research, clinical practice, and industry roles in veterinary microbiology and infectious disease management.
            </p>
          </motion.div>

          <div className="relative">
            <div className="absolute left-4 md:left-1/2 md:transform md:-translate-x-1/2 top-0 bottom-0 w-0.5 timeline-line"></div>
            
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className={`relative mb-12 ${index % 2 === 0 ? 'md:pr-1/2' : 'md:pl-1/2 md:ml-auto'}`}
              >
                <div className={`ml-12 md:ml-0 ${index % 2 === 1 ? 'md:ml-8' : 'md:mr-8'}`}>
                  <div className="absolute left-0 md:left-auto md:right-full md:mr-8 top-6 w-4 h-4 bg-primary rounded-full border-4 border-background shadow-lg"></div>
                  
                  <Card className="card-hover experience-card">
                    <CardHeader>
                      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                        <div>
                          <CardTitle className="text-xl">{exp.title}</CardTitle>
                          <CardDescription className="text-lg">{exp.company}</CardDescription>
                        </div>
                        <Badge variant="outline" className="mt-2 md:mt-0">
                          <Calendar size={14} className="mr-1" />
                          {exp.period}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{exp.description}</p>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">Key Responsibilities & Achievements:</h4>
                        <ul className="space-y-1">
                          {exp.achievements.map((achievement, achIndex) => (
                            <li key={achIndex} className="text-sm text-muted-foreground flex items-start">
                              <span className="w-1.5 h-1.5 bg-accent rounded-full mt-2 mr-2 shrink-0"></span>
                              {achievement}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Training & Internships */}
          <div className="mt-16">
            <h3 className="text-2xl font-bold mb-8 text-center">Training & Internships</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trainings.map((training, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="card-hover h-full">
                    <CardHeader>
                      <CardTitle className="text-lg leading-tight">{training.title}</CardTitle>
                      <CardDescription>{training.institution}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline">{training.duration}</Badge>
                        {training.role && (
                          <Badge variant="secondary">{training.role}</Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Skills & Expertise</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive technical skills spanning laboratory techniques, research methodologies, and data analysis tools.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src={microbiologyLabImg} 
                alt="Microbiology Laboratory" 
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              {skills.map((skill, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-sm text-muted-foreground">{skill.level}%</span>
                  </div>
                  <Progress value={skill.level} className="h-2" />
                </div>
              ))}
            </motion.div>
          </div>

          {/* Additional Skills */}
          <div className="mt-16">
            <div className="grid md:grid-cols-3 gap-8">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                viewport={{ once: true }}
              >
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <BarChart3 className="mr-2" size={24} />
                      Computer Skills
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Badge variant="outline">R Programming</Badge>
                      <Badge variant="outline">SPSS</Badge>
                      <Badge variant="outline">ArcGIS</Badge>
                      <Badge variant="outline">MS Office Suite</Badge>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Globe className="mr-2" size={24} />
                      Languages
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Bengali</span>
                        <Badge variant="default">Native</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>English</span>
                        <Badge variant="secondary">IELTS 7.0</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Hindi</span>
                        <Badge variant="outline">Elementary</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                viewport={{ once: true }}
              >
                <Card className="card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="mr-2" size={24} />
                      Professional Memberships
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm">Bangladesh Veterinary Council (2019-Present)</p>
                      <p className="text-sm">Chapai Nawabgonj Veterinary Association (2017-Present)</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Get In Touch</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              I'm always interested in discussing research opportunities, collaborations, or academic programs in veterinary microbiology and infectious disease research.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Mail className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold">Email</h3>
                  <p className="text-muted-foreground">nehal.has9@gmail.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Phone className="text-accent" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold">Phone</h3>
                  <p className="text-muted-foreground">+8801611-261993</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <MapPin className="text-primary" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold">Location</h3>
                  <p className="text-muted-foreground">Kabi Kazi Nazrul Islam Hall<br />Sher-e-Bangla Agricultural University<br />Dhaka-1207, Bangladesh</p>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <BookOpen className="text-accent" size={24} />
                </div>
                <div>
                  <h3 className="font-semibold">Google Scholar</h3>
                  <p className="text-muted-foreground">View my research publications</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Send a Message</CardTitle>
                  <CardDescription>
                    Feel free to reach out for research collaborations, academic opportunities, or professional inquiries.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">First Name</label>
                      <input 
                        type="text" 
                        className="w-full mt-1 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Last Name</label>
                      <input 
                        type="text" 
                        className="w-full mt-1 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Email</label>
                    <input 
                      type="email" 
                      className="w-full mt-1 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Subject</label>
                    <input 
                      type="text" 
                      className="w-full mt-1 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Research Collaboration Opportunity"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Message</label>
                    <textarea 
                      rows={4}
                      className="w-full mt-1 px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                      placeholder="Your message here..."
                    />
                  </div>
                  <Button className="w-full">
                    Send Message
                    <Mail className="ml-2" size={16} />
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            © 2024 MD Nehal Hasnain. All rights reserved. | Veterinary Microbiology Portfolio
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;

